import pygame
import random

# Initialize Pygame
pygame.init()

# Load the maze
def load_maze():
    return [
        [1, 1, 1, 1, 1, 1, 1],
        [1, 0, 0, 1, 0, 0, 1],
        [1, 1, 0, 1, 1, 1, 1],
        [0, 1, 1, 0, 0, 1, 0],
        [1, 1, 1, 1, 1, 1, 1]
    ]

maze = load_maze()

# Determine rows and columns dynamically
rows, cols = len(maze), len(maze[0])

# Get display dimensions and calculate cell size for fullscreen
display_info = pygame.display.Info()
screen_width, screen_height = display_info.current_w, display_info.current_h
extra_space = 100  # Space at the bottom for text
cell_size = min(screen_width // cols, (screen_height - extra_space) // rows)

# Adjust width and height for the maze
width, height = cols * cell_size, rows * cell_size

# Create fullscreen mode
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)
clock = pygame.time.Clock()

# Constants
MOVE_LIMIT = 700
POPULATION_SIZE = 1500
MUTATION_RATE = 0.6
MAX_GENERATIONS = 35

# Start and goal points
start, goal = (0, 0), (rows - 1, cols - 1)

# Font for rendering text
font = pygame.font.SysFont(None, 36)

# Genetic Algorithm Functions
def generate_chromosome():
    return [random.choice(['up', 'down', 'left', 'right']) for _ in range(MOVE_LIMIT)]

def move(position, direction):
    x, y = position
    if direction == 'up': return x - 1, y
    if direction == 'down': return x + 1, y
    if direction == 'left': return x, y - 1
    if direction == 'right': return x, y + 1
    return position

def is_valid(position):
    x, y = position
    return 0 <= x < rows and 0 <= y < cols and maze[x][y] == 1

def calculate_distance(position, target):
    return abs(position[0] - target[0]) + abs(position[1] - target[1])

def fitness(chromosome):
    position = start
    collisions, towards_start_penalty = 0, 0
    for move_direction in chromosome:
        next_position = move(position, move_direction)
        if is_valid(next_position):
            position = next_position
            towards_start_penalty += calculate_distance(position, start)
        else:
            collisions += 1
    distance_to_goal = calculate_distance(position, goal)
    return -distance_to_goal - collisions - towards_start_penalty

# Visualization
def draw_maze(screen, successful_runs):
    for x in range(rows):
        for y in range(cols):
            color = (255, 255, 255) if maze[x][y] == 1 else (0, 0, 0)
            pygame.draw.rect(screen, color, (y * cell_size, x * cell_size, cell_size, cell_size))
    # Highlight start and goal
    pygame.draw.rect(screen, (0, 0, 255), (start[1] * cell_size, start[0] * cell_size, cell_size, cell_size))  # Start
    pygame.draw.rect(screen, (255, 0, 0), (goal[1] * cell_size, goal[0] * cell_size, cell_size, cell_size))  # Goal

    # Display a label and total successes inside the goal cell
    label_text = font.render("Successes:", True, (255, 255, 255))
    success_text = font.render(f"{successful_runs}", True, (255, 255, 255))

    # Position the label and count inside the goal cell
    label_text_rect = label_text.get_rect(center=(
        goal[1] * cell_size + cell_size // 2,  # Center x
        goal[0] * cell_size + cell_size // 3   # Top part of the cell
    ))
    success_text_rect = success_text.get_rect(center=(
        goal[1] * cell_size + cell_size // 2,  # Center x
        goal[0] * cell_size + 2 * cell_size // 3  # Bottom part of the cell
    ))

    # Blit the label and count to the screen
    screen.blit(label_text, label_text_rect)
    screen.blit(success_text, success_text_rect)

def draw_path(screen, path):
    position = start  # Start at the initial position
    visited_positions = set()  # Keep track of visited positions
    closest_position = position  # Track the closest position to the goal
    min_distance_to_goal = calculate_distance(position, goal)  # Distance to the goal

    for move_direction in path:
        next_position = move(position, move_direction)

        # Ensure valid, not revisited, and not the goal position
        if is_valid(next_position) and next_position not in visited_positions and next_position != goal:
            # Draw the valid path in green
            pygame.draw.rect(screen, (0, 255, 0), 
                (next_position[1] * cell_size, next_position[0] * cell_size, cell_size, cell_size))
            visited_positions.add(next_position)  # Mark this position as visited
            position = next_position  # Update current position

            # Update closest position to the goal
            distance_to_goal = calculate_distance(position, goal)
            if distance_to_goal < min_distance_to_goal:
                min_distance_to_goal = distance_to_goal
                closest_position = position
        else:
            # Skip invalid, revisited, or goal moves
            continue

    # Draw the start in blue
    pygame.draw.rect(screen, (0, 0, 255), 
        (start[1] * cell_size, start[0] * cell_size, cell_size, cell_size))

    # Draw the tip of the path (closest to the goal) in purple if it's not the goal
    if closest_position != goal:
        pygame.draw.rect(screen, (128, 0, 128), 
            (closest_position[1] * cell_size, closest_position[0] * cell_size, cell_size, cell_size))



def draw_generation(screen, generation, batch_count, successful_runs):
    # Render text for generation, batch, and solve count
    generation_text = font.render(f"Generation: {generation}", True, (255, 255, 255))
    batch_text = font.render(f"Batch: {batch_count}", True, (255, 255, 255))
    success_text = font.render(f"Successes: {successful_runs}", True, (255, 255, 255))

    # Display the text on the screen (left side, below the maze)
    screen.blit(generation_text, (20, height + 20))  # Generation text
    screen.blit(batch_text, (20, height + 60))      # Batch text
    screen.blit(success_text, (20, height + 100))   # Success count text

    # Render descriptive line above parameters
    description_text = font.render(
        "Simulating Maze Pathfinding with Genetic Algorithms: Start = Blue, Closest Point = Purple, Goal = Red.",
        True,
        (255, 255, 255)
    )
    screen.blit(description_text, (screen_width - description_text.get_width() - 20, height + 20))  # Position above params

    # Render parameters as a single line in the bottom-right corner
    params_text = font.render(
        f"MOVE_LIMIT = {MOVE_LIMIT}   POPULATION_SIZE = {POPULATION_SIZE}   MUTATION_RATE = {MUTATION_RATE}   MAX_GENERATIONS = {MAX_GENERATIONS}",
        True,
        (255, 255, 255)
    )
    screen.blit(params_text, (screen_width - params_text.get_width() - 20, height + 60))  # Align to bottom-right


# Main loop
successful_runs = 0
batch_count = 0  # Tracks the number of batches
running = True

while running:
    batch_count += 1  # Increment batch count
    print(f"Starting Batch {batch_count}")  # Log batch start

    # Generate initial population
    population = [generate_chromosome() for _ in range(POPULATION_SIZE)]

    for generation in range(1, MAX_GENERATIONS + 1):
        print(f"Batch {batch_count}, Generation {generation}")  # Print generation count

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                exit()

        # Evaluate fitness
        fitness_scores = [fitness(ch) for ch in population]

        # Check if goal is reached
        best_index = fitness_scores.index(max(fitness_scores))
        best_chromosome = population[best_index]
        position = start
        for move_direction in best_chromosome:
            next_position = move(position, move_direction)
            if is_valid(next_position):
                position = next_position
            if position == goal:
                successful_runs += 1  # Increment success count
                print(f"Batch {batch_count}, Goal reached in generation {generation}. Total successes: {successful_runs}")
                break
        if position == goal:
            break

        # Selection, crossover, mutation
        parents = [population[i] for i in sorted(range(len(fitness_scores)), key=lambda k: fitness_scores[k], reverse=True)[:POPULATION_SIZE // 2]]
        new_population = []
        while len(new_population) < POPULATION_SIZE:
            # Select two parents
            parent1, parent2 = random.sample(parents, 2)
            
            # Crossover
            child = parent1[:MOVE_LIMIT // 2] + parent2[MOVE_LIMIT // 2:]
            
            # Mutation
            if random.random() < MUTATION_RATE:
                index_to_mutate = random.randint(0, len(child) - 1)
                child[index_to_mutate] = random.choice(['up', 'down', 'left', 'right'])
            
            # Add child to the new population
            new_population.append(child)
        population = new_population

        # Visualization
        screen.fill((0, 0, 0))
        draw_maze(screen, successful_runs)
        draw_path(screen, best_chromosome)
        draw_generation(screen, generation, batch_count, successful_runs)
        pygame.display.flip()
        pygame.time.delay(1250)

    pygame.time.delay(2500)  # Pause before starting next batch
