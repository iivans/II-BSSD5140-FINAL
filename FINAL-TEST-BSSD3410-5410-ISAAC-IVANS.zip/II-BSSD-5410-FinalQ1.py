from PIL import Image

def encode_message(image, message):
    # Convert message to binary
    binary_message = ''.join([format(ord(char), '08b') for char in message])
    binary_message += '11111111'  # signal the end of the message
    message_index = 0
    pixels = list(image.getdata())

    new_pixels = []
    for pixel in pixels:
        if message_index < len(binary_message):
            # Modify some of the first channel
            r = pixel[0] & ~1 | int(binary_message[message_index])
            new_pixels.append((r, pixel[1], pixel[2]))
            message_index += 1
        else:
            new_pixels.append(pixel)

    encoded_image = Image.new(image.mode, image.size)
    encoded_image.putdata(new_pixels)
    return encoded_image

def decode_message(image):
    pixels = list(image.getdata())
    binary_message = ''

    for pixel in pixels:
        binary_message += str(pixel[0] & 1)
        if binary_message.endswith('11111111'):
            break

    # Convert binary message back to text
    decoded_message = ''.join(
        chr(int(binary_message[i:i+8], 2)) for i in range(0, len(binary_message) - 8, 8)
    )
    return decoded_message

def main():
    while True:
        mode = input("Please enter mode (E)ncode or (D)ecode: ").strip().upper()
        if mode not in ['E', 'D']:
            print("Invalid mode. Try again.")
            continue

        image_name = input("Enter the image filename: ").strip()
        try:
            image = Image.open(image_name)
        except FileNotFoundError:
            print("File does not exist in folder.")
            continue

        # CHOOSE ENCODE
        if mode == 'E':
            message = input("Please enter the message to encode: ")
            encoded_image = encode_message(image, message)
            encoded_image.save('encoded_image.png')
            print("Encoded image saved as 'encoded_image.png'")

        # CHOOSE DECODE
        elif mode == 'D':
            decoded_message = decode_message(image)
            print(f"Found: {decoded_message}")

        another = input("Do you want to encode or decode another image? Y/N: ").strip().upper()
        if another != 'Y':
            print("DONE")
            break

if __name__ == "__main__":
    main()
