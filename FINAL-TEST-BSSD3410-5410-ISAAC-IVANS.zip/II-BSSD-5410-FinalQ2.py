#Make grid
def create_grid(grid_size, start_corner, stop_number):
    grid = [[0 for _ in range(grid_size)] for _ in range(grid_size)]

    # Directions for filling based on start corner
    # Top-left
    if start_corner == 1:  
        for row in range(grid_size):
            for col in range(grid_size):
                value = row + col + 1
                if value <= stop_number:
                    grid[row][col] = value
     # Top-right
    elif start_corner == 2: 
        for row in range(grid_size):
            for col in range(grid_size - 1, -1, -1):
                value = row + (grid_size - col)
                if value <= stop_number:
                    grid[row][col] = value
    # Bottom-left
    elif start_corner == 3:  
        for row in range(grid_size - 1, -1, -1):
            for col in range(grid_size):
                value = (grid_size - row) + col
                if value <= stop_number:
                    grid[row][col] = value
    # Bottom-right
    elif start_corner == 4:  
        for row in range(grid_size - 1, -1, -1):
            for col in range(grid_size - 1, -1, -1):
                value = (grid_size - row) + (grid_size - col)
                if value <= stop_number:
                    grid[row][col] = value

    return grid

# Print grid
def print_grid(grid):
    for row in grid:
        print(" ".join(map(str, row)))
        print(" ")

if __name__ == "__main__":

    # Input for grid size
    grid_size = int(input("Enter grid size 1-8: "))
    if not (1 <= grid_size <= 8):
        print("Grid size must be between 1 and 8.")
        exit()

    # lets you pick what corner to start in
    print("Choose starting corner:")
    print("1:Top-Left, 2:Top-Right, 3:Bottom-Left, 4:Bottom-Right")
    start_corner = int(input("Enter starting corner 1-4: "))
    if not (1 <= start_corner <= 4):
        print("Starting corner must be between 1 and 4.")
        exit()

    # lets you pick stop number
    stop_number = int(input("Enter stop number: "))
    if stop_number < 1:
        print("Stop number must be at least 1.")
        exit()

    # Create and display the grid
    grid = create_grid(grid_size, start_corner, stop_number)
    print("\n Grid: \n")
    print_grid(grid)
