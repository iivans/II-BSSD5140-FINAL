import random
from config import start, goal, MOVE_LIMIT, load_maze

def generate_chromosome():
    return [random.choice(['up', 'down', 'left', 'right']) for _ in range(MOVE_LIMIT)]

def move(position, direction):
    x, y = position
    if direction == 'up': return x - 1, y
    if direction == 'down': return x + 1, y
    if direction == 'left': return x, y - 1
    if direction == 'right': return x, y + 1
    return position

def is_valid(position):
    x, y = position
    maze = load_maze()
    return 0 <= x < len(maze) and 0 <= y < len(maze[0]) and maze[x][y] == 1

def calculate_distance(position, target):
    return abs(position[0] - target[0]) + abs(position[1] - target[1])

def fitness(chromosome):
    position = start
    collisions, towards_start_penalty = 0, 0
    for move_direction in chromosome:
        next_position = move(position, move_direction)
        if is_valid(next_position):
            position = next_position
            towards_start_penalty += calculate_distance(position, start)
        else:
            collisions += 1
    distance_to_goal = calculate_distance(position, goal)
    return -distance_to_goal - collisions - towards_start_penalty
