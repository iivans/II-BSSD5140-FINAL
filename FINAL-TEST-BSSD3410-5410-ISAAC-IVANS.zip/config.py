def load_maze():
    return [
        [1, 1, 1, 1, 1, 1, 1],
        [1, 0, 0, 1, 0, 0, 1],
        [1, 1, 0, 1, 1, 1, 1],
        [0, 1, 1, 0, 0, 1, 0],
        [1, 1, 1, 1, 1, 1, 1]
    ]

# Constants
start, goal = (0, 0), (4, 6)
MOVE_LIMIT = 700
POPULATION_SIZE = 1500
MUTATION_RATE = 0.6
MAX_GENERATIONS = 35
