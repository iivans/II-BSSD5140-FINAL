import pygame
import random
from config import load_maze, MOVE_LIMIT, POPULATION_SIZE, MUTATION_RATE, MAX_GENERATIONS, start, goal
from genetic_algorithm import generate_chromosome, move, is_valid, fitness
from visualization import draw_maze, draw_path, draw_generation

pygame.init()

maze = load_maze()
rows, cols = len(maze), len(maze[0])

display_info = pygame.display.Info()
screen_width, screen_height = display_info.current_w, display_info.current_h
extra_space = 100
cell_size = min(screen_width // cols, (screen_height - extra_space) // rows)
width, height = cols * cell_size, rows * cell_size

screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)

successful_runs = 0
batch_count = 0
running = True

while running:
    batch_count += 1
    print(f"Starting Batch {batch_count}")

    population = [generate_chromosome() for _ in range(POPULATION_SIZE)]

    for generation in range(1, MAX_GENERATIONS + 1):
        print(f"Batch {batch_count}, Generation {generation}")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                exit()

        fitness_scores = [fitness(ch) for ch in population]

        best_index = fitness_scores.index(max(fitness_scores))
        best_chromosome = population[best_index]
        position = start
        for move_direction in best_chromosome:
            next_position = move(position, move_direction)
            if is_valid(next_position):
                position = next_position
            if position == goal:
                successful_runs += 1
                print(f"Batch {batch_count}, Goal reached in generation {generation}. Total successes: {successful_runs}")
                break
        if position == goal:
            break

        parents = [population[i] for i in sorted(range(len(fitness_scores)), key=lambda k: fitness_scores[k], reverse=True)[:POPULATION_SIZE // 2]]
        new_population = []
        while len(new_population) < POPULATION_SIZE:
            parent1, parent2 = random.sample(parents, 2)
            child = parent1[:MOVE_LIMIT // 2] + parent2[MOVE_LIMIT // 2:]
            if random.random() < MUTATION_RATE:
                index_to_mutate = random.randint(0, len(child) - 1)
                child[index_to_mutate] = random.choice(['up', 'down', 'left', 'right'])
            new_population.append(child)
        population = new_population

        screen.fill((0, 0, 0))
        draw_maze(screen, successful_runs, font)
        draw_path(screen, best_chromosome, cell_size)
        draw_generation(screen, generation, batch_count, successful_runs, font)
        pygame.display.flip()
        pygame.time.delay(1250)

    pygame.time.delay(2500)
