import pygame
from config import start, goal, load_maze
from genetic_algorithm import move, is_valid, calculate_distance

def draw_maze(screen, successful_runs, font):
    maze = load_maze()
    rows, cols = len(maze), len(maze[0])
    cell_size = min(screen.get_width() // cols, (screen.get_height() - 100) // rows)

    for x in range(rows):
        for y in range(cols):
            color = (255, 255, 255) if maze[x][y] == 1 else (0, 0, 0)
            pygame.draw.rect(screen, color, (y * cell_size, x * cell_size, cell_size, cell_size))

    pygame.draw.rect(screen, (0, 0, 255), (start[1] * cell_size, start[0] * cell_size, cell_size, cell_size))
    pygame.draw.rect(screen, (255, 0, 0), (goal[1] * cell_size, goal[0] * cell_size, cell_size, cell_size))

    label_text = font.render("Successes:", True, (255, 255, 255))
    success_text = font.render(f"{successful_runs}", True, (255, 255, 255))

    label_text_rect = label_text.get_rect(center=(goal[1] * cell_size + cell_size // 2, goal[0] * cell_size + cell_size // 3))
    success_text_rect = success_text.get_rect(center=(goal[1] * cell_size + cell_size // 2, goal[0] * cell_size + 2 * cell_size // 3))

    screen.blit(label_text, label_text_rect)
    screen.blit(success_text, success_text_rect)

def draw_path(screen, path, cell_size):
    position = start
    visited_positions = set()
    closest_position = position
    min_distance_to_goal = float('inf')

    for move_direction in path:
        next_position = move(position, move_direction)
        if is_valid(next_position) and next_position not in visited_positions and next_position != goal:
            pygame.draw.rect(screen, (0, 255, 0), (next_position[1] * cell_size, next_position[0] * cell_size, cell_size, cell_size))
            visited_positions.add(next_position)
            position = next_position

            distance_to_goal = calculate_distance(position, goal)
            if distance_to_goal < min_distance_to_goal:
                min_distance_to_goal = distance_to_goal
                closest_position = position

    pygame.draw.rect(screen, (0, 0, 255), (start[1] * cell_size, start[0] * cell_size, cell_size, cell_size))
    if closest_position != goal:
        pygame.draw.rect(screen, (128, 0, 128), (closest_position[1] * cell_size, closest_position[0] * cell_size, cell_size, cell_size))

def draw_generation(screen, generation, batch_count, successful_runs, font):
    generation_text = font.render(f"Generation: {generation}", True, (255, 255, 255))
    batch_text = font.render(f"Batch: {batch_count}", True, (255, 255, 255))
    success_text = font.render(f"Successes: {successful_runs}", True, (255, 255, 255))

    screen.blit(generation_text, (20, screen.get_height() - 80))
    screen.blit(batch_text, (20, screen.get_height() - 60))
    screen.blit(success_text, (20, screen.get_height() - 40))
